package com.devglan.springboothibernatelogin;
import com.twilio.rest.api.v2010.account.Message;


public interface SMSService {

	
	public void sendSMS();
}
