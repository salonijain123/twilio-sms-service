package com.devglan.springboothibernatelogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHibernateLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHibernateLoginApplication.class, args);
	}

	public String hello()   
	{  
	
	return "Hello javaTpoint";  
	}

}