package com.devglan.springboothibernatelogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHibernateLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
